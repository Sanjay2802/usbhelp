## sdk_uvc_camera2

### UVCCamera2 cpp module
* libcamera
* libjpeg-turbo
* libusb
* libuvc
* libyuv